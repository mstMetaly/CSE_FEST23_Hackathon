
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const ejs = require('ejs');
const mongoose = require('mongoose');
const serverless = require('serverless-http');
const router = express.Router();

const PORT = 3000;

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Serve static files from the 'public' directory
app.use(express.static('public'));


// Connect to MongoDB
mongoose.connect('mongodb+srv://jarintasneem248:ArlZgoe7BhJ0u3D4@cluster0.diqmfcs.mongodb.net/?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Create a user schema
const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
});

// Create a user model
const User = mongoose.model('User', userSchema);

// Create an Express application


// Parse request bodies as JSON
router.use(bodyParser.json());

app.use('/.netlify/functions/server', router);  // path must route to lambda



// Define the route for the search page
router.get('/', (req, res) => {
  res.render('index');
});

router.get('/search', async (req, res) => {
  const authorName = req.query.author;
  const url = `https://openlibrary.org/search.json?author=${authorName}`;
  
  try {
    const response = await fetch(url);
    const data = await response.json();
    const books = data.docs.map((book) => ({
      title: book.title,
      publishedYear: book.first_publish_year,
      author: book.author_name ? book.author_name.join(', ') : 'N/A',
      price: book.price ? book.price : 'N/A',
      rating: book.rating ? book.rating.average : 'N/A',
    }));

    res.render('results', { books });
  } catch (error) {
    console.error('Error:', error);
    res.render('error');
  }
});

// Handle POST requests to /register
router.post('/register', async (req, res) => {
  const { name, email, password } = req.body;

  // Create a new user using the User model
  const newUser = new User({
    name,
    email,
    password,
  });

  try {
    // Save the user to the database
    await newUser.save();
    res.status(200).send('User successfully registered.');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error registering new user.');
  }
});


// Start the server
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});

module.exports.handler = serverless(app);